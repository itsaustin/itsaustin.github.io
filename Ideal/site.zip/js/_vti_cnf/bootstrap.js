vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Jun 2017 06:10:16 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|Ideal/Ideal/site/index.html
