vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Jul 2017 15:33:57 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|Austin-Notebook\\Austin
vti_modifiedby:SR|Austin-Notebook\\Austin
vti_timecreated:TR|27 Jun 2017 12:18:00 -0000
vti_backlinkinfo:VX|Ideal/Ideal/site/index.html
vti_nexttolasttimemodified:TW|11 Jul 2017 17:24:33 -0000
vti_cacheddtm:TX|11 Jul 2017 17:24:33 -0000
vti_filesize:IR|228
